import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

// ═══════════════════════════════════════════════════════
// Palette officielle Sawti v2
// Vert mauritanien profond + or CENI
// ═══════════════════════════════════════════════════════
class SC {
  static const forest   = Color(0xFF1A3A1E); // fond header principal
  static const jade     = Color(0xFF2D6A4F); // couleur primaire
  static const sage     = Color(0xFF52B788); // succès, validé
  static const cream    = Color(0xFFF7F5F0); // fond page
  static const white    = Color(0xFFFFFFFF);
  static const gold     = Color(0xFFC9A84C); // accent CENI
  static const goldPale = Color(0xFFF5EDD4);
  static const muted    = Color(0xFF6B7C6D); // texte secondaire
  static const border   = Color(0xFFD8E8D8);
  static const ink      = Color(0xFF0D1F0F);  // texte principal
  static const error    = Color(0xFFC0392B);
  static const errorBg  = Color(0xFFFDF0EE);
  static const successBg= Color(0xFFEAF5EA);
  static const infoBg   = Color(0xFFEAF3EB);
}

class AppTheme {
  // ── Police arabe ──────────────────────────────────────
  // Noto Naskh Arabic — lisible, officielle, belle
  static TextStyle arabicStyle({
    double fontSize = 14,
    FontWeight weight = FontWeight.w400,
    Color? color,
  }) => TextStyle(
    fontFamily: 'NotoNaskhArabic',
    fontSize: fontSize,
    fontWeight: weight,
    color: color ?? SC.ink,
    height: 1.5,
  );

  // ── Police latine ─────────────────────────────────────
  static TextStyle latinStyle({
    double fontSize = 14,
    FontWeight weight = FontWeight.w400,
    Color? color,
  }) => GoogleFonts.dmSans(
    fontSize: fontSize,
    fontWeight: weight,
    color: color ?? SC.ink,
  );

  // ── Police display ────────────────────────────────────
  static TextStyle displayStyle({
    double fontSize = 22,
    Color color = const Color(0xFFE8F5E9),
  }) => GoogleFonts.instrumentSerif(
    fontSize: fontSize,
    fontWeight: FontWeight.w400,
    color: color,
    height: 1.2,
  );

  static ThemeData get theme {
    return ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.light(
        primary:    SC.jade,
        secondary:  SC.gold,
        surface:    SC.white,
        background: SC.cream,
        error:      SC.error,
      ),
      scaffoldBackgroundColor: SC.cream,
      fontFamily: GoogleFonts.dmSans().fontFamily,
      textTheme: GoogleFonts.dmSansTextTheme().copyWith(
        displayLarge: GoogleFonts.instrumentSerif(
          fontSize: 28, fontWeight: FontWeight.w400, color: SC.ink,
        ),
        displayMedium: GoogleFonts.instrumentSerif(
          fontSize: 22, fontWeight: FontWeight.w400, color: SC.ink,
        ),
        bodyLarge:   GoogleFonts.dmSans(fontSize: 15, color: SC.ink),
        bodyMedium:  GoogleFonts.dmSans(fontSize: 13, color: SC.muted),
        labelSmall:  GoogleFonts.dmSans(
          fontSize: 10, fontWeight: FontWeight.w600,
          letterSpacing: 0.7, color: SC.muted,
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: SC.forest,
        foregroundColor: const Color(0xFFE8F5E9),
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        titleTextStyle: GoogleFonts.instrumentSerif(
          fontSize: 18, color: const Color(0xFFE8F5E9),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: SC.forest,
          foregroundColor: const Color(0xFFE8F5E9),
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w600),
          disabledBackgroundColor: const Color(0xFFC8D8C8),
          disabledForegroundColor: const Color(0xFF8A9A8A),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: SC.jade,
          side: const BorderSide(color: SC.border, width: 1.5),
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          textStyle: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w600),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: SC.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: SC.border, width: 1.5),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: SC.border, width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: SC.jade, width: 1.5),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(11),
          borderSide: const BorderSide(color: SC.error, width: 1.5),
        ),
        labelStyle: GoogleFonts.dmSans(color: SC.muted, fontSize: 13),
        hintStyle: GoogleFonts.dmSans(color: const Color(0xFFC8D8C8), fontSize: 13),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: SC.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: const BorderSide(color: SC.border, width: 1.5),
        ),
      ),
    );
  }
}
