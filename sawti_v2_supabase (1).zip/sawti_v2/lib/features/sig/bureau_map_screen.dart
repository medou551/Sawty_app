import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

import '../../data/models/bureau_model.dart';
import '../../data/services/bureau_service.dart';

class BureauMapScreen extends StatefulWidget {
  const BureauMapScreen({super.key});

  @override
  State<BureauMapScreen> createState() => _BureauMapScreenState();
}

class _BureauMapScreenState extends State<BureauMapScreen> {
  final BureauService _service = BureauService();
  List<BureauModel> _bureaux = [];
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadBureaux();
  }

  Future<void> _loadBureaux() async {
    try {
      final data = await _service.getBureaux();
      setState(() {
        _bureaux = data;
        _loading = false;
      });
    } catch (_) {
      setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Carte des bureaux')),
      body: FlutterMap(
        options: const MapOptions(
          initialCenter: LatLng(18.0735, -15.9582),
          initialZoom: 11,
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.example.sawti',
          ),
          MarkerLayer(
            markers: _bureaux.map((bureau) {
              return Marker(
                point: LatLng(bureau.latitude, bureau.longitude),
                width: 45,
                height: 45,
                child: GestureDetector(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) => AlertDialog(
                        title: Text(bureau.name),
                        content: Text(
                          'Région: ${bureau.region}\nMoughataa: ${bureau.moughataa}\nStatut: ${bureau.status}',
                        ),
                      ),
                    );
                  },
                  child: const Icon(Icons.location_on, color: Colors.red, size: 38),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}