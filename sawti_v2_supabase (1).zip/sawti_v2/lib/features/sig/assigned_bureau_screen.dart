import 'package:flutter/material.dart';

import '../../data/models/bureau_model.dart';
import '../../data/models/voter_status_model.dart';
import '../../data/services/auth_service.dart';
import '../../data/services/bureau_service.dart';
import '../../data/services/geo_service.dart';

class AssignedBureauScreen extends StatefulWidget {
  const AssignedBureauScreen({super.key});

  @override
  State<AssignedBureauScreen> createState() => _AssignedBureauScreenState();
}

class _AssignedBureauScreenState extends State<AssignedBureauScreen> {
  final AuthService _authService = AuthService();
  final BureauService _bureauService = BureauService();
  final GeoService _geoService = GeoService();

  bool _loading = true;
  String? _error;
  VoterStatusModel? _voterStatus;
  BureauModel? _bureau;
  double? _distanceKm;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final user = _authService.currentUser;
      if (user == null) {
        throw Exception('Utilisateur non connecté');
      }

      final voterStatus =
          await _bureauService.getCurrentUserVoterStatus(user.uid);
      if (voterStatus == null) {
        throw Exception('Statut électoral introuvable');
      }

      final bureau =
          await _bureauService.getBureauById(voterStatus.assignedBureauId);
      if (bureau == null) {
        throw Exception('Bureau assigné introuvable');
      }

      double? distanceKm;
      try {
        final position = await _geoService.getCurrentLocation();
        distanceKm = _geoService.distanceKm(
          fromLat: position.latitude,
          fromLng: position.longitude,
          toLat: bureau.latitude,
          toLng: bureau.longitude,
        );
      } catch (_) {
        distanceKm = null;
      }

      if (!mounted) return;
      setState(() {
        _voterStatus = voterStatus;
        _bureau = bureau;
        _distanceKm = distanceKm;
        _loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (_error != null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Mon bureau de vote')),
        body: Center(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  _error!,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      _loading = true;
                      _error = null;
                    });
                    _load();
                  },
                  child: const Text('Réessayer'),
                ),
              ],
            ),
          ),
        ),
      );
    }

    final bureau = _bureau!;
    final voterStatus = _voterStatus!;
    final isValidZone = _distanceKm == null ? false : _distanceKm! <= 20;

    return Scaffold(
      appBar: AppBar(title: const Text('Mon bureau de vote')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Card(
              child: ListTile(
                title: Text(bureau.name),
                subtitle: Text('${bureau.region} • ${bureau.moughataa}'),
                trailing: const Icon(Icons.how_to_vote),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                title: const Text('Statut électoral'),
                subtitle: Text(
                  voterStatus.hasVoted
                      ? 'Vote déjà enregistré'
                      : (voterStatus.eligible ? 'Éligible' : 'Non éligible'),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Card(
              child: ListTile(
                title: const Text('Distance actuelle'),
                subtitle: Text(
                  _distanceKm == null
                      ? 'Position non disponible'
                      : '${_distanceKm!.toStringAsFixed(2)} km',
                ),
              ),
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                color: isValidZone ? Colors.green.shade50 : Colors.orange.shade50,
              ),
              child: Text(
                _distanceKm == null
                    ? "Le bureau assigné est chargé, mais la géolocalisation n'est pas disponible."
                    : (isValidZone
                        ? 'Position géographique cohérente avec le bureau assigné.'
                        : 'Position éloignée du bureau assigné. Une alerte peut être créée pendant le vote.'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
