import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/theme/app_theme.dart';
import '../../l10n/strings.dart';
import '../../widgets/sawti_widgets.dart';

class SuccessScreen extends StatefulWidget {
  final String? bureauFr;
  final String? bureauAr;
  final String? distKm;
  final String? wilayaFr;
  final String? wilayaAr;

  const SuccessScreen({
    super.key,
    this.bureauFr,
    this.bureauAr,
    this.distKm,
    this.wilayaFr,
    this.wilayaAr,
  });

  @override
  State<SuccessScreen> createState() => _SuccessScreenState();
}

class _SuccessScreenState extends State<SuccessScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<double> _scale;
  late Animation<double> _fade;

  String get _ref {
    final now = DateTime.now();
    return '#SWT-${now.year}-${now.millisecondsSinceEpoch.toString().substring(7, 12)}';
  }

  String get _timestamp {
    final now = DateTime.now();
    const months = ['jan','fév','mar','avr','mai','jun','jul','aoû','sep','oct','nov','déc'];
    return '${now.day.toString().padLeft(2,'0')} ${months[now.month-1]} ${now.year}'
      ' · ${now.hour.toString().padLeft(2,'0')}:${now.minute.toString().padLeft(2,'0')}';
  }

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700));
    _scale = CurvedAnimation(parent: _ctrl, curve: Curves.elasticOut);
    _fade  = CurvedAnimation(parent: _ctrl, curve: Curves.easeIn);
    _ctrl.forward();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SC.cream,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: FadeTransition(
            opacity: _fade,
            child: Column(children: [
              const SizedBox(height: 32),

              // ── Icône animée ──────────────────────────
              ScaleTransition(
                scale: _scale,
                child: Container(
                  width: 84, height: 84,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: SC.successBg,
                    border: Border.all(color: SC.sage, width: 3),
                  ),
                  child: const Center(
                    child: Icon(Icons.check_rounded, color: SC.sage, size: 44),
                  ),
                ),
              ),
              const SizedBox(height: 18),

              // ── Titre bilingue ────────────────────────
              Text(S.successTitleFr, style: GoogleFonts.instrumentSerif(
                fontSize: 26, color: SC.forest,
              )),
              Text(S.successTitleAr,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                  fontFamily: 'NotoNaskhArabic',
                  fontSize: 22, color: SC.forest,
                )),
              const SizedBox(height: 10),
              Text(S.successSubFr,
                textAlign: TextAlign.center,
                style: GoogleFonts.dmSans(fontSize: 13, color: SC.muted, height: 1.7)),
              const SizedBox(height: 4),
              Text(S.successSubAr,
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                  fontFamily: 'NotoNaskhArabic',
                  fontSize: 13, color: SC.muted, height: 1.6,
                )),
              const SizedBox(height: 24),

              // ── Reçu officiel CENI ────────────────────
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: SC.white,
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: SC.border, width: 1.5),
                ),
                child: Column(children: [
                  // En-tête reçu
                  Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                    Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(S.receiptTitleFr, style: GoogleFonts.dmSans(
                        fontSize: 9, fontWeight: FontWeight.w700,
                        letterSpacing: 0.7, color: SC.muted,
                      )),
                      Text(S.receiptTitleAr,
                        textDirection: TextDirection.rtl,
                        style: const TextStyle(
                          fontFamily: 'NotoNaskhArabic',
                          fontSize: 10, color: SC.muted,
                        )),
                    ]),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                        color: SC.successBg,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text('Validé ✓ · صالح', style: GoogleFonts.dmSans(
                        fontSize: 10, fontWeight: FontWeight.w700, color: SC.jade,
                      )),
                    ),
                  ]),
                  const SizedBox(height: 12),
                  Divider(color: SC.border, height: 1),
                  const SizedBox(height: 10),

                  // Lignes du reçu
                  _row('Référence', 'المرجع', _ref),
                  _row('Horodatage', 'التوقيت', _timestamp),
                  if (widget.wilayaFr != null)
                    _row('Wilaya', 'الولاية',
                      '${widget.wilayaFr} · ${widget.wilayaAr ?? ""}'),
                  if (widget.bureauFr != null)
                    _row('Bureau de vote', 'مكتب التصويت', widget.bureauFr!),
                  if (widget.distKm != null)
                    _row('Distance GPS', 'مسافة GPS', '${widget.distKm} km ✓',
                      valColor: SC.sage),
                  _row('Chiffrement', 'التشفير', 'AES-256-GCM ✓'),
                  _row('NNI vérifié', 'الرقم الوطني', '●●●●●●●●90'),
                  _row('Statut', 'الحالة', 'Vote enregistré — تم التسجيل',
                    valColor: SC.jade),
                ]),
              ),
              const SizedBox(height: 18),

              // ── Bouton PDF ────────────────────────────
              SizedBox(
                width: double.infinity, height: 52,
                child: ElevatedButton.icon(
                  onPressed: () {
                    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: const Text('Téléchargement du reçu PDF… تحميل الإيصال…'),
                      backgroundColor: SC.jade,
                      behavior: SnackBarBehavior.floating,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10)),
                    ));
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: SC.gold,
                    foregroundColor: SC.forest,
                  ),
                  icon: const Icon(Icons.download_rounded, size: 18),
                  label: Text('${S.downloadPdfFr} · ${S.downloadPdfAr}',
                    style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w600)),
                ),
              ),
              const SizedBox(height: 10),

              // ── Retour élections ──────────────────────
              SizedBox(
                width: double.infinity, height: 52,
                child: OutlinedButton(
                  onPressed: () => context.go('/elections'),
                  child: Text('${S.backToVoteFr} · ${S.backToVoteAr}',
                    style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w600)),
                ),
              ),
              const SizedBox(height: 22),

              // ── Pied de page CENI ─────────────────────
              Column(children: [
                const Text('🇲🇷', style: TextStyle(fontSize: 22)),
                const SizedBox(height: 6),
                Text(S.countryFr, textAlign: TextAlign.center,
                  style: GoogleFonts.dmSans(fontSize: 10, color: SC.muted)),
                Text(S.ceniFullAr,
                  textAlign: TextAlign.center,
                  textDirection: TextDirection.rtl,
                  style: const TextStyle(
                    fontFamily: 'NotoNaskhArabic', fontSize: 11, color: SC.muted,
                  )),
                Text(S.ceniFullFr, textAlign: TextAlign.center,
                  style: GoogleFonts.dmSans(fontSize: 10, color: SC.muted)),
              ]),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _row(String keyFr, String keyAr, String val, {Color? valColor}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(children: [
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(keyFr, style: GoogleFonts.dmSans(fontSize: 11, color: SC.muted)),
          Text(keyAr,
            textDirection: TextDirection.rtl,
            style: const TextStyle(
              fontFamily: 'NotoNaskhArabic', fontSize: 10, color: SC.muted,
            )),
        ])),
        Text(val, style: GoogleFonts.dmSans(
          fontSize: 11, fontWeight: FontWeight.w700,
          color: valColor ?? SC.ink,
        )),
      ]),
    );
  }
}
