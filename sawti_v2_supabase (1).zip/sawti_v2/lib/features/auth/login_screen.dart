import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/constants/ceni_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../data/services/auth_service.dart';
import '../../l10n/strings.dart';
import '../../widgets/sawti_widgets.dart';

// ── Utilitaire opérateur + format téléphone ───────────
class _Phone {
  static MrOperator? operator(String digits) {
    if (digits.length < 2) return null;
    return CeniConstants.operators[digits.substring(0, 2)];
  }

  static bool validPrefix(String digits) =>
    digits.length < 2 || CeniConstants.operators.containsKey(digits.substring(0, 2));

  static String format(String raw) {
    final d = raw.replaceAll(RegExp(r'\D'), '')
      .substring(0, raw.replaceAll(RegExp(r'\D'), '').length.clamp(0, 8));
    final b = StringBuffer();
    for (int i = 0; i < d.length; i++) {
      if (i == 2 || i == 4 || i == 6) b.write(' ');
      b.write(d[i]);
    }
    return b.toString();
  }
}

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _phoneCtrl = TextEditingController();
  final _nniCtrl   = TextEditingController();
  final _nameCtrl  = TextEditingController();
  final _birthCtrl = TextEditingController();
  final _auth      = AuthService();

  Wilaya? _selectedWilaya;
  bool _loading = false;

  // ── Validation ──────────────────────────────────────
  String get _digits => _phoneCtrl.text.replaceAll(RegExp(r'\D'), '');
  bool get _validPhone   => _digits.length == 8 && _Phone.validPrefix(_digits);
  bool get _badPrefix    => _digits.length >= 2 && !_Phone.validPrefix(_digits);
  bool get _validNni     => RegExp(CeniConstants.nniPattern).hasMatch(_nniCtrl.text);
  bool get _validName    => _nameCtrl.text.trim().length >= 3;
  bool get _validBirth {
    final y = int.tryParse(_birthCtrl.text.trim());
    return y != null && (DateTime.now().year - y) >= CeniConstants.minVotingAge && y >= 1920;
  }
  bool get _canSend =>
    _validPhone && _validNni && _validName && _validBirth &&
    _selectedWilaya != null && !_loading;

  @override
  void dispose() {
    _phoneCtrl.dispose(); _nniCtrl.dispose();
    _nameCtrl.dispose();  _birthCtrl.dispose();
    super.dispose();
  }

  // ── Hint dynamique téléphone ─────────────────────────
  String get _phoneHintFr {
    if (_badPrefix) return '«${_digits.substring(0, 2)}» — ${S.errBadPrefixFr}';
    final op = _Phone.operator(_digits);
    if (_validPhone) return 'Opérateur : ${op!.name} · +222 ${_phoneCtrl.text}';
    if (op != null)  return 'Opérateur détecté : ${op.name} — continuez';
    return 'Indicatifs : 20–23 (Mauritel) · 36–39 (Mattel) · 46–49 (Chinguitel)';
  }

  String get _phoneHintAr {
    if (_badPrefix) return S.errBadPrefixAr;
    final op = _Phone.operator(_digits);
    if (_validPhone) return 'المشغّل : ${op!.ar} · الرقم مكتمل';
    if (op != null)  return 'المشغّل : ${op.ar} — أكمل الإدخال';
    return 'بادئات : ٢٠–٢٣ (موريتيل) · ٣٦–٣٩ (ماتيل) · ٤٦–٤٩ (شنقيتيل)';
  }

  HintKind get _phoneHintKind =>
    _badPrefix ? HintKind.bad : _validPhone ? HintKind.good : HintKind.neutral;

  // ── Envoi OTP ────────────────────────────────────────
  Future<void> _send() async {
    setState(() => _loading = true);
    final full = '+222$_digits';
    await _auth.sendOtp(
      phoneNumber: full,
      onCodeSent: (vId) {
        if (!mounted) return;
        setState(() => _loading = false);
        context.push('/otp', extra: {
          'phoneNumber':  full,
          'verificationId': vId,
          'nni':          _nniCtrl.text.trim(),
          'fullName':     _nameCtrl.text.trim(),
          'birthYear':    int.parse(_birthCtrl.text.trim()),
          'wilayaId':     _selectedWilaya!.id,
          'wilayaFr':     _selectedWilaya!.fr,
          'wilayaAr':     _selectedWilaya!.ar,
        });
      },
      onError: (e) {
        if (!mounted) return;
        setState(() => _loading = false);
        _snack(e, isError: true);
      },
    );
  }

  void _snack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? SC.error : SC.jade,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SC.cream,
      body: Column(children: [
        SawtiHeader(
          emoji: '🗳',
          titleFr: S.loginTitleFr,
          subtitleFr: S.countryFr,
          subtitleAr: S.countryAr,
        ),

        Expanded(child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 30),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

            // ── Téléphone ──────────────────────────────
            BiLabel(fr: S.phoneLabelFr, ar: S.phoneLabelAr),
            Row(crossAxisAlignment: CrossAxisAlignment.center, children: [
              // Préfixe pays
              Container(
                height: 48,
                padding: const EdgeInsets.symmetric(horizontal: 11),
                decoration: BoxDecoration(
                  color: SC.infoBg,
                  border: Border.all(color: SC.border, width: 1.5),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Row(children: [
                  const Text('🇲🇷', style: TextStyle(fontSize: 15)),
                  const SizedBox(width: 6),
                  Text('+222', style: GoogleFonts.dmSans(
                    fontSize: 12, fontWeight: FontWeight.w700, color: SC.jade,
                  )),
                ]),
              ),
              const SizedBox(width: 8),
              // Champ digits
              Expanded(child: Container(
                decoration: BoxDecoration(
                  color: _badPrefix ? SC.errorBg : SC.white,
                  border: Border.all(
                    color: _badPrefix ? SC.error
                        : _validPhone ? SC.jade : SC.border,
                    width: 1.5,
                  ),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Row(children: [
                  Expanded(child: TextField(
                    controller: _phoneCtrl,
                    keyboardType: TextInputType.phone,
                    maxLength: 11,
                    style: GoogleFonts.dmSans(
                      fontSize: 18, fontWeight: FontWeight.w700,
                      letterSpacing: 2, color: SC.ink,
                    ),
                    decoration: InputDecoration(
                      counterText: '',
                      hintText: '__ __ __ __',
                      hintStyle: GoogleFonts.dmSans(
                        color: const Color(0xFFC8D8C8),
                        letterSpacing: 2, fontSize: 16,
                      ),
                      border: InputBorder.none,
                      enabledBorder: InputBorder.none,
                      focusedBorder: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 13),
                    ),
                    onChanged: (v) {
                      final fmt = _Phone.format(v);
                      if (fmt != v) {
                        _phoneCtrl.value = TextEditingValue(
                          text: fmt,
                          selection: TextSelection.collapsed(offset: fmt.length),
                        );
                      }
                      setState(() {});
                    },
                  )),
                  if (_validPhone)
                    const Padding(padding: EdgeInsets.only(right: 10),
                      child: Icon(Icons.check_circle_rounded, color: SC.jade, size: 18))
                  else if (_badPrefix)
                    const Padding(padding: EdgeInsets.only(right: 10),
                      child: Icon(Icons.error_rounded, color: SC.error, size: 18)),
                ]),
              )),
            ]),
            const SizedBox(height: 7),
            PhoneSegmentBar(filled: _digits.length, isError: _badPrefix),
            const SizedBox(height: 7),
            BiHintBox(fr: _phoneHintFr, ar: _phoneHintAr, kind: _phoneHintKind),

            // ── NNI ────────────────────────────────────
            BiLabel(fr: S.nniLabelFr, ar: S.nniLabelAr),
            _buildInput(
              controller: _nniCtrl,
              hint: S.nniHintFr,
              maxLen: 10,
              isValid: _validNni,
              formatters: [FilteringTextInputFormatter.digitsOnly],
              counterText: '${_nniCtrl.text.length}/10',
              letterSpacing: 1.8,
            ),

            // ── Nom complet ────────────────────────────
            BiLabel(fr: S.nameLabelFr, ar: S.nameLabelAr),
            _buildInput(
              controller: _nameCtrl,
              hint: 'أحمد ولد محمد',
              isValid: _validName,
              caps: TextCapitalization.words,
            ),

            // ── Naissance + Wilaya ─────────────────────
            Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                BiLabel(fr: S.birthLabelFr, ar: S.birthLabelAr),
                _buildInput(
                  controller: _birthCtrl,
                  hint: '1990',
                  maxLen: 4,
                  isValid: _validBirth,
                  formatters: [FilteringTextInputFormatter.digitsOnly],
                  center: true,
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                ),
              ])),
              const SizedBox(width: 10),
              Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                BiLabel(fr: S.wilayaLabelFr, ar: S.wilayaLabelAr),
                _buildWilayaDropdown(),
              ])),
            ]),
            const SizedBox(height: 4),

            // Aide âge
            if (_birthCtrl.text.length == 4 && !_validBirth)
              BiHintBox(fr: S.errAgeMinFr, ar: S.errAgeMinAr, kind: HintKind.bad),

            const SizedBox(height: 16),
            Divider(color: SC.border),
            const SizedBox(height: 14),

            // ── Bouton CTA ─────────────────────────────
            BiButton(
              fr: S.sendOtpFr,
              ar: S.sendOtpAr,
              isLoading: _loading,
              onPressed: _canSend ? _send : null,
            ),
            const SizedBox(height: 14),
            Column(children: [
              Text(S.securityFr,
                textAlign: TextAlign.center,
                style: GoogleFonts.dmSans(fontSize: 10, color: SC.muted)),
              const SizedBox(height: 2),
              Text(S.securityAr,
                textAlign: TextAlign.center,
                textDirection: TextDirection.rtl,
                style: const TextStyle(
                  fontFamily: 'NotoNaskhArabic', fontSize: 11, color: SC.muted,
                )),
            ]),
          ]),
        )),
      ]),
    );
  }

  // ── Constructeur de champ générique ──────────────────
  Widget _buildInput({
    required TextEditingController controller,
    required String hint,
    bool isValid = false,
    int? maxLen,
    List<TextInputFormatter>? formatters,
    String? counterText,
    double letterSpacing = 0,
    TextCapitalization caps = TextCapitalization.none,
    bool center = false,
    double fontSize = 13,
    FontWeight fontWeight = FontWeight.w400,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextField(
        controller: controller,
        maxLength: maxLen,
        inputFormatters: formatters,
        textCapitalization: caps,
        textAlign: center ? TextAlign.center : TextAlign.start,
        style: GoogleFonts.dmSans(
          fontSize: fontSize, fontWeight: fontWeight,
          letterSpacing: letterSpacing, color: SC.ink,
        ),
        decoration: InputDecoration(
          hintText: hint,
          counterText: counterText ?? '',
          suffixIcon: isValid
            ? const Icon(Icons.check_circle_rounded, color: SC.jade, size: 18)
            : null,
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(11),
            borderSide: BorderSide(
              color: isValid ? SC.jade : SC.border, width: 1.5,
            ),
          ),
        ),
        onChanged: (_) => setState(() {}),
      ),
    );
  }

  // ── Dropdown wilayas ──────────────────────────────────
  Widget _buildWilayaDropdown() {
    return Container(
      height: 48,
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: SC.white,
        border: Border.all(
          color: _selectedWilaya != null ? SC.jade : SC.border, width: 1.5,
        ),
        borderRadius: BorderRadius.circular(11),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<Wilaya>(
          value: _selectedWilaya,
          isExpanded: true,
          hint: Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Text('Wilaya', style: GoogleFonts.dmSans(
              fontSize: 13, color: SC.muted,
            )),
          ),
          icon: const Padding(
            padding: EdgeInsets.only(right: 8),
            child: Icon(Icons.arrow_drop_down_rounded, color: SC.muted),
          ),
          onChanged: (w) => setState(() => _selectedWilaya = w),
          items: CeniConstants.wilayas.map((w) => DropdownMenuItem(
            value: w,
            child: Padding(
              padding: const EdgeInsets.only(left: 12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(w.fr, style: GoogleFonts.dmSans(fontSize: 12, fontWeight: FontWeight.w500)),
                  Text(w.ar,
                    textDirection: TextDirection.rtl,
                    style: const TextStyle(
                      fontFamily: 'NotoNaskhArabic', fontSize: 11, color: SC.muted,
                    )),
                ],
              ),
            ),
          )).toList(),
        ),
      ),
    );
  }
}
