import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import '../../core/theme/app_theme.dart';
import '../../data/services/auth_service.dart';
import '../../l10n/strings.dart';
import '../../widgets/sawti_widgets.dart';

class OtpScreen extends StatefulWidget {
  final String phoneNumber;
  final String verificationId;
  final String nni;
  final String fullName;
  final int birthYear;
  final String wilayaId;
  final String wilayaFr;
  final String wilayaAr;

  const OtpScreen({
    super.key,
    required this.phoneNumber,
    required this.verificationId,
    required this.nni,
    required this.fullName,
    required this.birthYear,
    required this.wilayaId,
    required this.wilayaFr,
    required this.wilayaAr,
  });

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {
  final _auth = AuthService();
  bool _loading = false;
  String _otp   = '';
  int _seconds  = 60;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    _startTimer();
  }

  void _startTimer() {
    _seconds = 60;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (!mounted) { t.cancel(); return; }
      setState(() { if (_seconds > 0) _seconds--; else t.cancel(); });
    });
  }

  String get _timerLabel {
    final m = (_seconds ~/ 60).toString().padLeft(2, '0');
    final s = (_seconds % 60).toString().padLeft(2, '0');
    return '$m:$s';
  }

  String get _maskedPhone {
    // +222 36 XX XX 34 → +222 36 ●● ●● 34
    if (widget.phoneNumber.length < 8) return widget.phoneNumber;
    return widget.phoneNumber.replaceRange(
      widget.phoneNumber.length - 6, widget.phoneNumber.length - 2, '●● ●● ',
    );
  }

  @override
  void dispose() { _timer?.cancel(); super.dispose(); }

  Future<void> _verify() async {
    if (_otp.length < 6) return;
    setState(() => _loading = true);
    try {
      await _auth.verifyOtp(
        verificationId: widget.verificationId,
        smsCode: _otp,
      );
      if (!mounted) return;
      context.go('/elections');
    } catch (e) {
      if (!mounted) return;
      _snack('Code incorrect — رمز خاطئ', isError: true);
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _resend() async {
    if (_seconds > 0) return;
    try {
      await _auth.sendOtp(
        phoneNumber: widget.phoneNumber,
        onCodeSent: (_) { if (mounted) _startTimer(); },
        onError: (e) => _snack(e, isError: true),
      );
    } catch (_) {}
  }

  void _snack(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: isError ? SC.error : SC.jade,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: SC.cream,
      body: Column(children: [
        SawtiHeader(
          emoji: '🔐',
          titleFr: S.otpTitleFr,
          subtitleFr: 'Envoyé au $_maskedPhone',
          subtitleAr: 'أُرسل إلى $_maskedPhone',
        ),

        Expanded(child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(18, 10, 18, 30),
          child: Column(children: [

            const SizedBox(height: 8),
            Text(S.otpSubFr,
              textAlign: TextAlign.center,
              style: GoogleFonts.dmSans(fontSize: 13, color: SC.muted, height: 1.6)),
            const SizedBox(height: 4),
            Text(S.otpSubAr,
              textAlign: TextAlign.center,
              textDirection: TextDirection.rtl,
              style: const TextStyle(
                fontFamily: 'NotoNaskhArabic',
                fontSize: 13, color: SC.muted, height: 1.6,
              )),
            const SizedBox(height: 24),

            // ── 6 cases OTP ────────────────────────────
            OtpInput(onComplete: (otp) {
              _otp = otp;
              _verify();
            }),
            const SizedBox(height: 18),

            // ── Compte à rebours ────────────────────────
            Container(
              padding: const EdgeInsets.symmetric(vertical: 14),
              child: Column(children: [
                Text(_timerLabel,
                  style: GoogleFonts.dmSans(
                    fontSize: 28, fontWeight: FontWeight.w700, color: SC.forest,
                  )),
                const SizedBox(height: 3),
                Text('ينتهي الرمز خلال · Code valide encore',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontFamily: 'NotoNaskhArabic', fontSize: 11, color: SC.muted,
                  )),
              ]),
            ),

            BiHintBox(
              fr: S.otpSecurityFr,
              ar: S.otpSecurityAr,
              kind: HintKind.neutral,
            ),

            BiButton(
              fr: S.otpValidateFr,
              ar: S.otpValidateAr,
              isLoading: _loading,
              onPressed: _otp.length == 6 ? _verify : null,
            ),
            const SizedBox(height: 18),

            // ── Renvoi ─────────────────────────────────
            GestureDetector(
              onTap: _resend,
              child: Column(children: [
                Text(
                  _seconds > 0
                    ? '${S.otpResendFr} dans ${_seconds}s'
                    : '→ ${S.otpResendFr}',
                  style: GoogleFonts.dmSans(
                    fontSize: 12, fontWeight: FontWeight.w600,
                    color: _seconds > 0 ? SC.muted : SC.jade,
                  ),
                ),
                Text(
                  _seconds > 0
                    ? '${S.otpResendAr} (${_seconds}ث)'
                    : '← ${S.otpResendAr}',
                  textDirection: TextDirection.rtl,
                  style: TextStyle(
                    fontFamily: 'NotoNaskhArabic', fontSize: 11,
                    color: _seconds > 0 ? SC.muted : SC.jade,
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 24),

            // ── Badge sécurité ─────────────────────────
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: SC.infoBg,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: SC.border),
              ),
              child: Row(children: [
                const Text('🛡', style: TextStyle(fontSize: 20)),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(
                    'Votre identité est vérifiée via votre NNI. Aucune donnée personnelle n\'est liée à votre vote.',
                    style: GoogleFonts.dmSans(fontSize: 11, color: SC.muted, height: 1.6),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'هويتك تُتحقق منها عبر رقمك الوطني. لا توجد بيانات شخصية مرتبطة بصوتك.',
                    textDirection: TextDirection.rtl,
                    style: TextStyle(
                      fontFamily: 'NotoNaskhArabic',
                      fontSize: 11, color: SC.muted, height: 1.5,
                    ),
                  ),
                ])),
              ]),
            ),
          ]),
        )),
      ]),
    );
  }
}
